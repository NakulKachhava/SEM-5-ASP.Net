﻿using FluentValidation;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PracticalTest.Common;
using PracticalTest.Data;
using PracticalTest.DTO;
using PracticalTest.Models;
using PracticalTest.Validators;

namespace PracticalTest.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly PTDbContext _context;
        private readonly IValidator<ProductDto> _validator;
        public ProductController(PTDbContext context, ProductValidator validator)
        {
            _context = context;
            _validator = validator;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllProducts()
        {
            var products = await _context.Products.Select(x => new ProductDto
            {
                ProductId = x.ProductId,
                ProductName = x.ProductName,
                ProductCode = x.ProductCode,
                Price = x.Price,
                Category = x.Category,
                StockQuantity = x.StockQuantity,
                ManufactureDate = x.ManufactureDate,
                ExpiryDate = x.ExpiryDate,
                IsAvailable = x.IsAvailable,
            }).AsNoTracking().ToListAsync();
            return Ok(new ApiResponse<List<ProductDto>>
            {
                Success = true,
                Message = "Products Retrieved Successfully.",
                Data = products
            });
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> Getproduct([FromRoute] int id)
        {
            var product = await _context.Products.FindAsync(id);

            if (product == null)
            {
                return NotFound(new ApiResponse<object>
                {
                    Success = false,
                    Message = "product Not Found",
                    Errors = new List<string> { $"No product found with Id {id}" }
                });
            }

            var newproduct = new ProductDto
            {
                ProductId = product.ProductId,
                ProductName = product.ProductName,
                ProductCode = product.ProductCode,
                Price = product.Price,
                Category = product.Category,
                StockQuantity = product.StockQuantity,
                ManufactureDate = product.ManufactureDate,
                ExpiryDate = product.ExpiryDate,
                IsAvailable = product.IsAvailable,
            };

            return Ok(new ApiResponse<ProductDto>
            {
                Success = true,
                Message = "product Retrieved Successfully",
                Data = newproduct,
            });
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] ProductDto product)
        {
            try
            {
                var result = await _validator.ValidateAsync(product);

                if (!result.IsValid)
                {
                    return BadRequest(new ApiResponse<Object>
                    {
                        Success = false,
                        Message = "Validation Failed",
                        Data = null,
                        //Errors = result.Errors
                        //.Select(x => $"{x.PropertyName}: {x.ErrorMessage}")
                        //.ToList()

                        Errors = result.Errors
                        .GroupBy(x => x.PropertyName)
                        .Select(x => $"{x.Key}: {string.Join(", ", x.Select(e => e.ErrorMessage))}")
                        .ToList()
                    });
                }

                if (product == null)
                {
                    return BadRequest(new ApiResponse<object>
                    {
                        Success = false,
                        Message = "Product Object Not Found",
                        Errors = new List<string> { $"Given Product object was not found." }
                    });
                }

                var Products = new Product()
                {
                    ProductName = product.ProductName,
                    ProductCode = product.ProductCode,
                    Price = product.Price,
                    Category = product.Category,
                    StockQuantity = product.StockQuantity,
                    ManufactureDate = product.ManufactureDate,
                    ExpiryDate = product.ExpiryDate,
                    IsAvailable = product.IsAvailable,
                };

                await _context.Products.AddAsync(Products);
                await _context.SaveChangesAsync();

                return Ok(new ApiResponse<ProductDto>
                {
                    Success = true,
                    Message = "Product Added Successfully",
                    Data = product,
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse<Object>
                {
                    Success = false,
                    Message = "Error occurred while adding Product",
                    Errors = new List<string>
                    {
                        ex.Message,
                        ex.InnerException?.Message ?? "No Inner Exception"
                    }
                });
            }
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update([FromRoute] int id, [FromBody] ProductDto product)
        {
            try
            {
                var result = await _validator.ValidateAsync(product);

                if (!result.IsValid)
                {
                    return BadRequest(new ApiResponse<Object>
                    {
                        Success = false,
                        Message = "Validation Failed.",
                        Data = null,
                        //Errors = result.Errors
                        //.Select(x => $"{x.PropertyName}: {x.ErrorMessage}")
                        //.ToList()

                        Errors = result.Errors
                        .GroupBy(x => x.PropertyName)
                        .Select(x => $"{x.Key}: {string.Join(", ", x.Select(e => e.ErrorMessage))}")
                        .ToList()

                    });
                }

                if (id != product.ProductId)
                    return BadRequest(new ApiResponse<Object>
                    {
                        Success = false,
                        Message = "Product ID Mismatch",
                        Errors = new List<string> { $"ProductID does not match with Given Id {id}" }
                    });

                var oldProduct = await _context.Products.FindAsync(id);

                if (oldProduct == null)
                    return NotFound(new ApiResponse<object>
                    {
                        Success = false,
                        Message = "Product Not Found",
                        Errors = new List<string> { $"No Product found with Id {id}" }
                    });

                oldProduct.ProductName = product.ProductName;
                oldProduct.ProductCode = product.ProductCode;
                oldProduct.Price = product.Price;
                oldProduct.StockQuantity = product.StockQuantity;
                oldProduct.Category = product.Category;
                oldProduct.ManufactureDate = product.ManufactureDate;
                oldProduct.ExpiryDate = product.ExpiryDate;
                oldProduct.IsAvailable = product.IsAvailable;
                await _context.SaveChangesAsync();

                return Ok(new ApiResponse<ProductDto>
                {
                    Success = true,
                    Message = "Product Updated Successfully",
                    Data = product
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse<Object>
                {
                    Success = false,
                    Message = "Error occurred while updating product",
                    Errors = new List<string>
                    {
                        ex.Message,
                        ex.InnerException?.Message ?? "No Inner Exception"
                    }
                });
            }
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete([FromRoute] int id)
        {
            try
            {
                var product = await _context.Products.FindAsync(id);

                if (product == null)
                    return NotFound(new ApiResponse<object>
                    {
                        Success = false,
                        Message = "Product Not Found",
                        Errors = new List<string> { $"No Product found with Id {id}" }
                    });

                _context.Products.Remove(product);
                await _context.SaveChangesAsync();

                return Ok(new ApiResponse<object>
                {
                    Success = true,
                    Message = $"Product with Id {id} Deleted Successfully",
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse<object>
                {
                    Success = false,
                    Message = "Error occurred while deleting product",
                    Errors = new List<string> { ex.Message }
                });
            }
        }

        [HttpGet("available")]
        public async Task<IActionResult> GetAvailableProducts()
        {
            var products = await _context.Products.Where(x => x.IsAvailable).Select(x => new ProductDto
            {
                ProductId = x.ProductId,
                ProductName = x.ProductName,
                ProductCode = x.ProductCode,
                Price = x.Price,
                Category = x.Category,
                StockQuantity = x.StockQuantity,
                ManufactureDate = x.ManufactureDate,
                ExpiryDate = x.ExpiryDate,
                IsAvailable = x.IsAvailable,
            }).AsNoTracking().ToListAsync();
            return Ok(new ApiResponse<List<ProductDto>>
            {
                Success = true,
                Message = "Available Products Retrieved Successfully.",
                Data = products
            });
        }

        [HttpGet("price-range")]
        public async Task<IActionResult> GetProductsWithinPriceRange([FromQuery] decimal min, [FromQuery] decimal max)
        {
            var products = await _context.Products.Where(x => x.Price >= min && x.Price <= max).Select(x => new ProductDto
            {
                ProductId = x.ProductId,
                ProductName = x.ProductName,
                ProductCode = x.ProductCode,
                Price = x.Price,
                Category = x.Category,
                StockQuantity = x.StockQuantity,
                ManufactureDate = x.ManufactureDate,
                ExpiryDate = x.ExpiryDate,
                IsAvailable = x.IsAvailable,
            }).AsNoTracking().ToListAsync();
            return Ok(new ApiResponse<List<ProductDto>>
            {
                Success = true,
                Message = "Products Within Price Range Retrieved Successfully.",
                Data = products
            });
        }

        [HttpGet("summary")]
        public async Task<IActionResult> GetProductSummary()
        {
            var summaryData = await _context.Products
                .GroupBy(p => 1)
                .Select(g => new
                {
                    TotalProducts = g.Count(),
                    AvailableProducts = g.Count(p => p.IsAvailable), 
                    AveragePrice = g.Average(p => p.Price)           
                })
                .FirstOrDefaultAsync();

            return Ok(new ApiResponse<object>
            {
                Success = true,
                Message = "Products Summary Retrieved Successfully.",
                Data = summaryData
            });
        }

    }
}
