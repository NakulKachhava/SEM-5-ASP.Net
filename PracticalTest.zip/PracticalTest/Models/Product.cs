﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PracticalTest.Models
{
    public class Product
    {
        [Key]
        public int ProductId { get; set; }
        
        [Required, MaxLength(100)]
        public string ProductName { get; set; } = string.Empty;

        [Required, MaxLength(50)]
        public string ProductCode { get; set; } = string.Empty;

        [Required, MaxLength(50)]
        public string Category { get; set; } = string.Empty;

        [Column(TypeName = "decimal(18,2)")] // OR You can use [Precision(18, 2)]
        public decimal Price { get; set; }

        public int StockQuantity { get; set; }

        public DateTime ManufactureDate { get; set; }
        
        public DateTime ExpiryDate { get; set; }

        [Required]
        public bool IsAvailable { get; set; }

    }
}
