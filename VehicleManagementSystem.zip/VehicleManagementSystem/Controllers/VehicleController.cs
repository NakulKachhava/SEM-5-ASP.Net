﻿using FluentValidation;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VehicleManagementSystem.Common;
using VehicleManagementSystem.Data;
using VehicleManagementSystem.DTO;
using VehicleManagementSystem.Models;

namespace VehicleManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VehicleController : ControllerBase
    {
        private readonly VMDbContext _context;
        private readonly IValidator<VehicleDto> _validator;

        public VehicleController(VMDbContext context, IValidator<VehicleDto> validator)
        {
            _context = context;
            _validator = validator;
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] VehicleDto dto)
        {
            var result = await _validator.ValidateAsync(dto);
            if (!result.IsValid)
            {
                return BadRequest(new ApiResponse<Object>
                {
                    Success = false,
                    Message = "Validation Failed",
                    Data = null,
                    //Errors = result.Errors
                    //.Select(x => $"{x.PropertyName}: {x.ErrorMessage}")
                    //.ToList()

                    Errors = result.Errors
                        .GroupBy(x => x.PropertyName)
                        .Select(x => $"{x.Key}: {string.Join(", ", x.Select(e => e.ErrorMessage))}")
                        .ToList()
                });
            }

            var vehicle = new Vehicle
            {
                VehicleName = dto.VehicleName,
                RegistrationNumber = dto.RegistrationNumber,
                VehicleType = dto.VehicleType,
                ModelYear = dto.ModelYear,
                RentalPrice = dto.RentalPrice,
                RegistrationDate = dto.RegistrationDate,
                LastServiceDate = dto.LastServiceDate,
                IsAvailable = dto.IsAvailable
            };

            await _context.Vehicles.AddAsync(vehicle);
            await _context.SaveChangesAsync();

            return Ok(new ApiResponse<VehicleDto>
            {
                Success = true,
                Message = "Vehicle Added Successfully",
                Data = dto,
            });
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var vehicles = await _context.Vehicles
                .Select(v => MapToDto(v))
                .ToListAsync();

            var response = new ApiResponse<List<VehicleDto>> { Success = true, Message = "Vehicles retrieved successfully.", Data = vehicles };
            return Ok(response); 
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var vehicle = await _context.Vehicles.FindAsync(id);
            if (vehicle == null)
            {
                var errorResponse = new ApiResponse<object> { Success = false, Message = "Vehicle not found.", Errors = new List<string> { $"Vehicle with ID {id} does not exist." } };
                return NotFound(errorResponse);
            }

            var response = new ApiResponse<VehicleDto> { Success = true, Message = "Vehicle found.", Data = MapToDto(vehicle) };
            return Ok(response);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] VehicleDto dto)
        {
            if (id != dto.VehicleId)
            {
                var mismatchResponse = new ApiResponse<object> { Success = false, Message = "Payload invalid.", Errors = new List<string> { "Route parameter ID doesn't match object payload ID." } };
                return BadRequest(mismatchResponse);
            }
            var validationResult = await _validator.ValidateAsync(dto);
            if (!validationResult.IsValid)
            {
                var errors = validationResult.Errors.Select(e => e.ErrorMessage).ToList();
                var badResponse = new ApiResponse<object> { Success = false, Message = "Validation failed.", Errors = errors };
                return BadRequest(badResponse); 
            }

            var vehicle = await _context.Vehicles.FindAsync(id);
            if (vehicle == null)
            {
                var errorResponse = new ApiResponse<object> { Success = false, Message = "Vehicle not found.", Errors = new List<string> { $"Vehicle with ID {id} does not exist." } };
                return NotFound(errorResponse); 
            }

            vehicle.VehicleName = dto.VehicleName;
            vehicle.RegistrationNumber = dto.RegistrationNumber;
            vehicle.VehicleType = dto.VehicleType;
            vehicle.ModelYear = dto.ModelYear;
            vehicle.RentalPrice = dto.RentalPrice;
            vehicle.RegistrationDate = dto.RegistrationDate;
            vehicle.LastServiceDate = dto.LastServiceDate;
            vehicle.IsAvailable = dto.IsAvailable;

            await _context.SaveChangesAsync();

            var response = new ApiResponse<VehicleDto> { Success = true, Message = "Vehicle updated successfully.", Data = MapToDto(vehicle) };
            return Ok(response);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var vehicle = await _context.Vehicles.FindAsync(id);
            if (vehicle == null)
            {
                var errorResponse = new ApiResponse<object> { Success = false, Message = "Vehicle not found.", Errors = new List<string> { $"Vehicle with ID {id} does not exist." } };
                return NotFound(errorResponse);
            }

            _context.Vehicles.Remove(vehicle);
            await _context.SaveChangesAsync();

            var response = new ApiResponse<object> { Success = true, Message = "Vehicle deleted successfully.", Data = new { DeletedId = id } };
            return Ok(response); 
        }

        [HttpGet("available")]
        public async Task<IActionResult> GetAvailable()
        {
            var availableVehicles = await _context.Vehicles
                .Where(v => v.IsAvailable)
                .Select(v => MapToDto(v))
                .ToListAsync();

            var response = new ApiResponse<List<VehicleDto>> { Success = true, Message = "Available vehicles retrieved.", Data = availableVehicles };
            return Ok(response);
        }

        [HttpGet("search")]
        public async Task<IActionResult> Search([FromQuery] string name)
        {
            var results = await _context.Vehicles
                .Where(v => v.VehicleName.Contains(name))
                .Select(v => MapToDto(v))
                .ToListAsync();

            var response = new ApiResponse<List<VehicleDto>> { Success = true, Message = $"Search results for keyword '{name}' template.", Data = results };
            return Ok(response);
        }

        [HttpGet("rent-range")]
        public async Task<IActionResult> GetByRentRange([FromQuery] decimal min, [FromQuery] decimal max)
        {
            var results = await _context.Vehicles
                .Where(v => v.RentalPrice >= min && v.RentalPrice <= max)
                .Select(v => MapToDto(v))
                .ToListAsync();

            var response = new ApiResponse<List<VehicleDto>> { Success = true, Message = $"Vehicles priced between {min} and {max} retrieved.", Data = results };
            return Ok(response);
        }

        // GET /api/vehicles/service-before?date=2026-09-01 - Date filter criteria
        [HttpGet("service-before")]
        public async Task<IActionResult> GetServicedBefore([FromQuery] DateTime date)
        {
            var results = await _context.Vehicles
                .Where(v => v.LastServiceDate < date)
                .Select(v => MapToDto(v))
                .ToListAsync();

            var response = new ApiResponse<List<VehicleDto>> { Success = true, Message = $"Vehicles last serviced before {date:yyyy-MM-dd} retrieved.", Data = results };
            return Ok(response);
        }

        // GET /api/vehicles/summary - Data aggregation dashboard endpoint
        [HttpGet("summary")]
        public async Task<IActionResult> GetSummary()
        {
            var summaryData = await _context.Vehicles
                .GroupBy(v => 1)
                .Select(g => new
                {
                    Total = g.Count(),
                    Available = g.Count(v => v.IsAvailable),
                    Unavailable = g.Count(v => !v.IsAvailable),
                    AverageRentalPrice = g.Average(v => v.RentalPrice)
                })
                .FirstOrDefaultAsync();

            var finalSummary = summaryData ?? new { Total = 0, Available = 0, Unavailable = 0, AverageRentalPrice = 0.0m };
            var response = new ApiResponse<object> { Success = true, Message = "Summary operational telemetry metrics compiled.", Data = finalSummary };
            return Ok(response);
        }

        private static VehicleDto MapToDto(Vehicle vehicle) => new()
        {
            VehicleId = vehicle.VehicleId,
            VehicleName = vehicle.VehicleName,
            RegistrationNumber = vehicle.RegistrationNumber,
            VehicleType = vehicle.VehicleType,
            ModelYear = vehicle.ModelYear,
            RentalPrice = vehicle.RentalPrice,
        };
    }
}