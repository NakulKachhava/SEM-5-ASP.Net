﻿using FluentValidation;
using System;
using System.Linq;
using VehicleManagementSystem.DTO;

namespace VehicleManagementSystem.Validators
{
    public class VehicleValidator : AbstractValidator<VehicleDto>
    {
        public VehicleValidator()
        {
            RuleLevelCascadeMode = CascadeMode.Stop;

            RuleFor(x => x.VehicleName)
                .NotEmpty().WithMessage("VehicleName is required.")
                .MinimumLength(2).WithMessage("VehicleName must be at least 2 characters long.")
                .MaximumLength(100).WithMessage("VehicleName must not exceed 100 characters.")
                .Must(name => name == null || (name.Length == name.Trim().Length))
                    .WithMessage("VehicleName must not contain leading or trailing whitespace.");

            RuleFor(x => x.RegistrationNumber)
                .NotEmpty().WithMessage("RegistrationNumber is required.")
                .Must(regNum => regNum == null || !regNum.Any(char.IsWhiteSpace))
                    .WithMessage("RegistrationNumber must not contain whitespace.");

            RuleFor(x => x.VehicleType)
                .NotEmpty().WithMessage("VehicleType is required.");

            RuleFor(x => x.ModelYear)
                .GreaterThan(1900).WithMessage("ModelYear must be greater than 1900.")
                .LessThanOrEqualTo(DateTime.Now.Year).WithMessage("ModelYear must not exceed current year.");

            RuleFor(x => x.RentalPrice)
                .GreaterThan(0).WithMessage("RentalPrice must be greater than 0.");

            RuleFor(x => x.RegistrationDate)
                .LessThanOrEqualTo(DateTime.Now).WithMessage("RegistrationDate must not be a future date.");

            RuleFor(x => x.LastServiceDate)
                .LessThanOrEqualTo(DateTime.Now).WithMessage("LastServiceDate must not be a future date.")
                .Must((vehicle, lastService) => lastService <= vehicle.RegistrationDate)
                    .WithMessage("LastServiceDate must not be greater than RegistrationDate.");
        }
    }
}
