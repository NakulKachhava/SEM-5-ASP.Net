﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VehicleManagementSystem.Models
{
    [Table("Vehicles")]
    public class Vehicle
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int VehicleId { get; set; }

        [Required]
        [Column(TypeName = "varchar(100)")]
        public string VehicleName { get; set; } = string.Empty;

        [Required]
        [Column(TypeName = "varchar(50)")]
        public string RegistrationNumber { get; set; } = string.Empty;

        [Required]
        [Column(TypeName = "varchar(50)")]
        public string VehicleType { get; set; } = string.Empty;

        [Required]
        public int ModelYear { get; set; }

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal RentalPrice { get; set; }

        [Required]
        [Column(TypeName = "datetime")]
        public DateTime RegistrationDate { get; set; }

        [Required]
        [Column(TypeName = "datetime")]
        public DateTime LastServiceDate { get; set; }

        [Required]
        public bool IsAvailable { get; set; }
    }
}
