﻿using Microsoft.EntityFrameworkCore;
using VehicleManagementSystem.Models;

namespace VehicleManagementSystem.Data
{
    public class VMDbContext : DbContext
    {
        public VMDbContext(DbContextOptions<VMDbContext> options)
            : base(options)
        {
        }

        public DbSet<Vehicle> Vehicles => Set<Vehicle>();
    }
}
