﻿using System;

namespace VehicleManagementSystem.DTO
{
    public class VehicleDto
    {
        public int VehicleId { get; set; }
        public string VehicleName { get; set; } = string.Empty;
        public string RegistrationNumber { get; set; } = string.Empty;
        public string VehicleType { get; set; } = string.Empty;
        public int ModelYear { get; set; }
        public decimal RentalPrice { get; set; }
        public DateTime RegistrationDate { get; set; }
        public DateTime LastServiceDate { get; set; }
        public bool IsAvailable { get; set; }
    }
}
