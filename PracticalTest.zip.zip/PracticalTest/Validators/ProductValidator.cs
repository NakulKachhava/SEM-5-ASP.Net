﻿using FluentValidation;
using PracticalTest.DTO;

namespace PracticalTest.Validators
{
    public class ProductValidator : AbstractValidator<ProductDto>
    {
        public ProductValidator()
        {
            RuleFor(p => p.ProductName)
                .NotEmpty()
                .WithMessage("Product Name is required.")

                .MinimumLength(3)
                .WithMessage("Product Name must have at least 3 characters.")

                .MaximumLength(100)
                .WithMessage("Product Name can not exceed 100 characters.");

            RuleFor(p => p.ProductCode)
                .NotEmpty()
                .WithMessage("Product Code is required.")

                .Must(code => !string.IsNullOrWhiteSpace(code))
                .WithMessage("Product code can not be empty or contain whitespaces.");

            RuleFor(p => p.Category)
                .NotEmpty()
                .WithMessage("Category is required.");

            RuleFor(p => p.Price)
                .GreaterThan(0)
                .WithMessage("Price must be greater than 0.")

                .LessThanOrEqualTo(1000000)
                .WithMessage("Price must not exceed 10,00,000.");

            RuleFor(p => p.StockQuantity)
                .GreaterThanOrEqualTo(0)
                .WithMessage("StockQuantity must be greater than or equal to 0.");

            RuleFor(p => p.ManufactureDate)
                .LessThan(DateTime.Now)
                .WithMessage("Manufacture Date can not be a future date.");
        }
    }
}
