﻿using System.ComponentModel.DataAnnotations;

namespace PracticalTest.Models
{
    public class Product
    {
        [Key]
        public int ProductId { get; set; }
        
        [Required, MaxLength(100)]
        public string ProductName { get; set; } = string.Empty;

        [Required, MaxLength(50)]
        public string ProductCode { get; set; } = string.Empty;

        [Required, MaxLength(50)]
        public string Category { get; set; } = string.Empty;
       
        public decimal Price { get; set; }

        public int StockQuantity { get; set; }

        public DateTime ManufactureDate { get; set; }
        
        public DateTime ExpiryDate { get; set; }
        
        public bool? IsAvailable { get; set; }

    }
}
