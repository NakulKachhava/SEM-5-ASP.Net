﻿using Microsoft.EntityFrameworkCore;
using PracticalTest.Models;
using PracticalTest.Data;

namespace PracticalTest.Data
{
    public class PTDbContext : DbContext
    {
        public PTDbContext(DbContextOptions<PTDbContext> options)
            : base(options)
        {
        }

        public DbSet<Product> Products => Set<Product>();

    }
}
