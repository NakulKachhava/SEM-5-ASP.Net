﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PracticalTest.Common;
using PracticalTest.Data;
using PracticalTest.DTO;
using PracticalTest.Models;
using PracticalTest.Validators;

namespace PracticalTest.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly PTDbContext _context;
        private readonly ProductValidator _validator;
        public ProductController(PTDbContext context, ProductValidator validator)
        {
            _context = context;
            _validator = validator;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllProducts()
        {
            var products = await _context.Products.Select(x => new ProductDto
            {
                ProductId = x.ProductId,
                ProductName = x.ProductName,
                ProductCode = x.ProductCode,
                Price = x.Price,
                Category = x.Category,
                StockQuantity = x.StockQuantity,
                ManufactureDate = x.ManufactureDate,
                ExpiryDate = x.ExpiryDate,
                IsAvailable = x.IsAvailable,
            }).AsNoTracking().ToListAsync();
            return Ok(new ApiResponse<List<ProductDto>>
            {
                Success = true,
                Message = "Products Retrieved Successfully.",
                Data = products
            });
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Getproduct(int id)
        {
            var product = await _context.Products.FindAsync(id);

            if (product == null)
            {
                return NotFound(new ApiResponse<object>
                {
                    Success = false,
                    Message = "product Not Found",
                    Errors = new List<string> { $"No product found with Id {id}" }
                });
            }

            var newproduct = new ProductDto
            {
                ProductId = product.ProductId,
                ProductName = product.ProductName,
                ProductCode = product.ProductCode,
                Price = product.Price,
                Category = product.Category,
                StockQuantity = product.StockQuantity,
                ManufactureDate = product.ManufactureDate,
                ExpiryDate = product.ExpiryDate,
                IsAvailable = product.IsAvailable,
            };

            return Ok(new ApiResponse<ProductDto>
            {
                Success = true,
                Message = "product Retrieved Successfully",
                Data = newproduct,
            });
        }

        [HttpPost]
        public async Task<IActionResult> Create(ProductDto product)
        {
            try
            {
                var result = await _validator.ValidateAsync(product);

                if (!result.IsValid)
                {
                    return BadRequest(new ApiResponse<Object>
                    {
                        Success = false,
                        Message = "Validation Failed",
                        Data = null,
                        //Errors = result.Errors
                        //.Select(x => $"{x.PropertyName}: {x.ErrorMessage}")
                        //.ToList()

                        Errors = result.Errors
                        .GroupBy(x => x.PropertyName)
                        .Select(x => $"{x.Key}: {string.Join(", ", x.Select(e => e.ErrorMessage))}")
                        .ToList()
                    });
                }

                if (product == null)
                {
                    return BadRequest(new ApiResponse<object>
                    {
                        Success = false,
                        Message = "Product Object Not Found",
                        Errors = new List<string> { $"Given Product object was not found." }
                    });
                }

                var Products = new Product()
                {
                    ProductName = product.ProductName,
                    ProductCode = product.ProductCode,
                    Price = product.Price,
                    Category = product.Category,
                    StockQuantity = product.StockQuantity,
                    ManufactureDate = product.ManufactureDate,
                    ExpiryDate = product.ExpiryDate,
                    IsAvailable = product.IsAvailable,
                };

                await _context.Products.AddAsync(Products);
                await _context.SaveChangesAsync();

                return Ok(new ApiResponse<ProductDto>
                {
                    Success = true,
                    Message = "Product Added Successfully",
                    Data = product,
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse<Object>
                {
                    Success = false,
                    Message = "Error occurred while adding Product",
                    Errors = new List<string>
                    {
                        ex.Message,
                        ex.InnerException?.Message ?? "No Inner Exception"
                    }
                });
            }
        }
    }
}
