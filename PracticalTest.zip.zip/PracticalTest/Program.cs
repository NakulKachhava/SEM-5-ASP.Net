
using FluentValidation;
using Microsoft.EntityFrameworkCore;
using PracticalTest.Validators;
using Scalar.AspNetCore;
using PracticalTest.Data;

namespace PracticalTest
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            builder.Services.AddControllers(options => options.ModelValidatorProviders.Clear());
            // Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi

            builder.Services.AddValidatorsFromAssemblyContaining<ProductValidator>();
            builder.Services.AddDbContext<PTDbContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));
            builder.Services.AddOpenApi();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.MapOpenApi();
                app.MapScalarApiReference();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}
